function setup() {
  createCanvas(400, 400);
  
  
  
  
}

function draw() {
  background(220);
if (gameState === "play"){
  score = score+ math.Round (getframeRate/30);
  ground.velocitX =-4;
}
  
  
  
}
